#!/usr/bin/ruby
#This program was written by spencer shefchik
#This program will NEARLY fix your problem with garbage text. 
#You will still need to go back and fix the final "," needed at the end of some lines without gender
#use ctrl + h and then alt + r to get to regex
#firstName,LastName,Email,State,Phone,TZ,DatePulled
def leftside
	somefile = File.open("sample.txt", "w")
	somefile.puts "FirstName,LastName,Email,State,Phone,TZ,DateRecieved,"
	#check if it should be new line.
	count = 0
	if File.exists?("mistakes.txt")
		File.read("mistakes.txt").each do |line|
			line.strip!
			#Date Received
			if line.match(/[0-9]{4}\/[0-9]{2}\/[0-9]{2}/)
				puts line[/[0-9]{4}\/[0-9]{2}\/[0-9]{2}/]
				somefile.print "#{line[/[0-9]{4}\/[0-9]{2}\/[0-9]{2}/]},"
				count = count + 1
				puts "count #{count}"
			end
			#FirstName and Lastname
			if line.match(/^[A-Za-z]+\s[A-Za-z]+$/)
				puts line[/[A-Za-z]+/]
				somefile.print "#{line[/[A-Za-z]+/]},"	
				puts line[/\s[A-Za-z]+/] + ","
				somefile.print "\n#{line[/\s[A-Za-z]+/]},"
			end
			#email
			if line.match(/[A-Za-z0-9\.\-]+[@][a-z]+[.]/)
				puts line[/[A-Za-z0-9\.\-]+[@][a-z]+[.]com/]
				somefile.print "#{line[/[A-Za-z0-9\-\.]+[@][a-z]+[.]com/]},"
			end
			#city			
			# if line.match(/[A-Za-z]+[,]\s+[A-Z]{2}/)
			# 	puts line[/[A-Za-z]+/]
			# 	somefile.print "#{line[/[A-Za-z]+/]},"
			# end

			#state
			if line.match(/[,]\s+[A-Z]{2}/)
				puts line[/\s[A-Z]{2}/]
				somefile.print "#{line[/[A-Z]{2}/]},"
			end
			#zipcode
			# if line.match(/^\d{5}$/)
			# 	puts line[/^\d{5}$/]
			# 	somefile.print "#{line[/^\d{5}$/]},"
			# end
			#phone
			if line.match(/[0-9]{10}/)
				puts line[/[0-9]{10}/]
				somefile.print "#{line[/[0-9]{10}/]},"
			end
			#timezone
			if line.match(/[(][0-9]{3}[)]\s[0-9]{3}[-][0-9]{4}/)
				puts line[/[A-Z]{3}/]
				somefile.print "#{line[/\s[A-Z]{3}/]},"
			end
			# #gender	m	
			# if line.match(/[M]{1}/)
			# 	puts "M"
			# 	somefile.print "M"
			# end
			# #gender f
			# if line.match(/[F]{1}/)
			# 	puts "F"
			# 	somefile.print "F"
			# end		
		end
	else
		puts "no meminfo found"
	end
	somefile.close
end
leftside