#!/usr/bin/ruby
#This program was written by spencer shefchik

if File.exists?("/proc/meminfo")
	File.read("/proc/meminfo").each do |line|
		if line.match(/#{ARGV[0]}/)
			puts line[/\s[0-9]+\s[A-Za-z]+/]
		end
	end
else
	puts "no meminfo found"
end