#!/usr/bin/ruby
#This program was written by spencer shefchik

def genusername(name)
	if !name[/[^a-z A-Z]/] # search for any non letters or whitespace, then invert
		puts "#{name[/\s([A-Za-z]+)$/, 1]}#{name[/^([A-Za-z])/, 1]}#{rand(1..9)}" # find last name, then first letter, random number
	else
		puts "Invalid Name"
	end
end
name = ""
while name != "quit"
	puts "Enter a name: "
	name = gets.chomp.downcase
	if name !="quit"
		genusername(name)
	end
end
