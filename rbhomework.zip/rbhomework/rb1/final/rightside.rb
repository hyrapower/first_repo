#!/usr/bin/ruby
#This program was written by spencer shefchik
#This program will NEARLY fix your problem with garbage text. 
#You will still need to go back and fix the final "," needed at the end of some lines without gender
#use ctrl + h and then alt + r to get to regex

def rightside
	somefile = File.open("sample2.txt", "w")
	#check if it should be new line.
	check = 0
	if File.exists?("mistakes.txt")
		File.read("mistakes.txt").each do |line|

			line = line.strip!
			#name
			if line.match(/\s[A-Za-z]+\s[A-Za-z]+/)
				puts line[/\s[A-Za-z]+\s[A-Za-z]+/].strip!
				somefile.print "\n#{line[/\s[A-Za-z]+\s[A-Za-z]+/]},"
			end
			#email
			if line.match(/\s[A-Za-z0-9\.\-]+[@][a-z]+[.]/)
				puts line[/\s[A-Za-z0-9\.\-]+[@][a-z]+[.]com/]
				somefile.print "#{line[/\s[A-Za-z0-9\-\.]+[@][a-z]+[.]com/]},".strip!
			end
			#state
			if line.match(/\s[,]\s+[A-Z]+/)
				puts line[/\s[A-Z]+/].strip!
				somefile.print "#{line[/\s[A-Z]+/]},".strip!
			end
			#phone
			if line.match(/\s[(][0-9]{3}[)]\s[0-9]{3}[-][0-9]{4}/)
				puts line[/\s[(][0-9]{3}[)]\s[0-9]{3}[-][0-9]{4}/].strip!
				somefile.print "#{line[/\s[(][0-9]{3}[)]\s[0-9]{3}[-][0-9]{4}/]},".strip!
			end
			#timezone
			if line.match(/\s[(][0-9]{3}[)]\s[0-9]{3}[-][0-9]{4}/)
				puts line[/\s[A-Z]{3}/].strip!
				somefile.print "#{line[/\s[A-Z]{3}/]},".strip!
			end	
			#gender	m	
			if line.match(/\s[M]{1}\s/)
				puts "M"
				somefile.print "M"
				check = 0
			end
			#gender f
			if line.match(/\s[F]{1}\s/)
				puts "F"
				somefile.print "F"
			end		
		end
	else
		puts "no meminfo found"
	end
	somefile.close
end