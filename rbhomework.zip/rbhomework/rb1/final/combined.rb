#!/usr/bin/ruby
#This program was written by spencer shefchik
#this file runs and combines leftside and rightside files
require "./rightside.rb"
require "./leftside.rb"

combined = File.open("fixed2.csv", "w")

if File.exists?("rightside.rb") && File.exists?("leftside.rb")
	leftside
	rightside
else
	puts "required files not found"
end


if File.exists?("fixed2.csv")
	File.open("fixed2.csv")
		File.read("sample.txt").each do |line|
			combined.puts line
		end		
		File.read("sample2.txt").each do |line|
			combined.puts line
		end
	combined.close
end
