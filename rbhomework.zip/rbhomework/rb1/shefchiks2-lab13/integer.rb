#/usr/bin/ruby
# This program is written by Spencer Shefchik
class Integer
  def to_oct
    puts self.to_base(8)
  end
  def to_base(b)
    n = self
    result = ""
    while n > 0
      result = result.prepend("#{n % b}")
      n = n / b
    end
    print result
  end
end
  puts "give me a number"
  num = gets.chomp.to_i

  num.to_oct