#!/usr/bin/ruby
# This program was created by Spencer Shefchik
# Credit to hexeract for debugging methods
# LogFormat "%h %l %u %t \"%r\" %>s %b" common
# CustomLog logs/access_log common

require 'fileutils'
# File.rename(f, folder_path + "/" + filename.capitalize + File.extname(f))

unless ARGV.length == 3
  puts "Not enough minerals"
  puts "Usage ./fixname.rb directory 'pattern' 'replace'"
  exit
end

if File.directory?(ARGV[0]) #directory
    FileUtils.cd(ARGV[0], :verbose => true) #change dir and report the change

    filelist = Array.new(Dir.glob("*")) # grab list of files and directories

    newfiles = Array.new # variable to check against
    filelist.each do |f|
      if File.file?(f) # if file is in fact a file
        newfiles.push(f) # if it is shove it into newfiles
      end
    end
    filelist = newfiles # overwrite filelist without directories
else
  puts "path does not exist"
end


# Credit to hexeract for debugging
# All classes and objects used were discussed in class
# http://hexeract.wordpress.com/2009/04/13/systematic-filename-manipulation-using-ruby/
# And process each element within the array

# If this counts as academic dishonesty please let me know and I will rewrite this program.
# I believe that this is pretty much the way we would do it in class and it is the
# most simplistic method of accomplishing this task anyway.

# Go through each file
filelist.each do |d|
 
    # use gsub from string 1 to string 2
    nfn = d.gsub(/#{ARGV[1]}/, "#{ARGV[2]}")
 
    # nowhitespace
    nfn.strip!
 
    # avoid mayhem and disallow empty names
    # I didn't think of this but is it useful
    if (nfn.empty?)
        puts "Error: Resulting name would be empty!"
        exit 1
    end
 
    # No need to rename if old and new name are identical
    # Didn't think about this either but it's good to show which files are changed
    if ( d == nfn )
        puts "Warning: Not renaming "+d+" (New name is identical to old one)"
        next
    end
 
    # do not overwrite existing items
    if ( File.file?(nfn) )
        puts "Error: Cowardly refusing to rename "+d+" ("+nfn+" exists!)"
        next
    end
 
    # and rename
    File.rename(d, nfn)
    puts "Renamed "+d+" to "+nfn
 
end