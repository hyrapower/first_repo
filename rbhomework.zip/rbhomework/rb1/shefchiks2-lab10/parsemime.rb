#!/usr/bin/ruby

#mime file found at /etc/mime.types

#while line = $stdin.gets
#	$stdout.puts line
#end

types = Hash.new

#open the file
File.open("/etc/mime.types", "r") do |file|
	file.each_line do |line|
		#get rid of junk lines
		next if line[0] == ?#
		next if line == "\n"
		line.strip!
		#split the key and value for the hash
		key, value = line.split(/\W+\s/)
		#put the values in the keys
		types[key] = value
	end
	#output for each
	types.each do |key, value|
		if value.nil?
			puts "#{key} has no extentions found."
		else
			puts "#{key} has extentions: #{value}"
		end
	end
end
