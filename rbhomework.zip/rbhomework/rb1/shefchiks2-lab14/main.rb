#/usr/bin/ruby
# This program is copied by Spencer Shefchik

require './dice' #changed path from dice to ./dice
	class Game
        include Dice
	end
g=Game.new
g.roll
g.roll