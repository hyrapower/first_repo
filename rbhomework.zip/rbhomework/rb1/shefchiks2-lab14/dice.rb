#/usr/bin/ruby
# This program is copied by Spencer Shefchik

module Dice
    def roll
        r1=rand(6)+1
        r2=rand(6)+1
        total=r1+r2
        puts "You rolled " + total.to_s
        total
    end
end