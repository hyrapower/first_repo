#/usr/bin/ruby
# This program was created by Spencer Shefchik

# create an array of user values, end with "q"
i = Array.new
x = 0
val = 0

# get list from user
puts "I will create a list for you. Enter q to stop creating the list."
while val != "q"
	print "Input a value: "
  val = gets.chomp
	if val != "q" && val.length > 0
  	i[x] = val
  	x += 1
  end
end
print i

imax = i.length

# get valid index, if value is -1 exit
# all non-numerics will be converted to 0 using to_i
while val != -1
	begin
	print "Enter an index between 0 and #{imax - 1} or -1 to quit: "
	val = gets.chomp.to_i
	if val != -1
		puts i.fetch(val)
	end	
	rescue
	puts "That is an invald index!"
	end
end

#too many bangs
puts "Have a nice day!"