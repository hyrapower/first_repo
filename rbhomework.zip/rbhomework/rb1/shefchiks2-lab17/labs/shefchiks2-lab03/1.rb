#!/usr/bin/ruby

# This program was written by Spencer Shefchik
puts "I will add two numbers for you"
puts "Enter the first number: "
first = gets.chomp.to_i
puts first
puts "Enter the 2nd number: "
second = gets.chomp.to_i
puts second
third = second + first
puts third
puts "#{first} + #{second} = #{third}"
