#!/usr/bin/ruby

#This program is written by Spencer Shefchik

arr=Array.new(3)
puts "Please enter a number: "
arr[0] = gets.chomp.to_f
puts "Enter the 2nd number: "
arr[1] = gets.chomp.to_f
puts "Enter the 3rd number: "
arr[2] = gets.chomp.to_f
puts "the numbers you entered were: "
puts arr[0..2]
sum = 0
arr.each { |a| sum += a }
puts "The sum of the numbers is: #{sum}"

