#!/usr/bin/ruby
#This program is written by Spencer Shefchik
puts "If I have 912 million bits how big is the drive in mb?"
bit=8
kilo=1024
mega=1024
puts 912000000/mega/kilo/bit
puts 912000000.0/mega/kilo/bit
