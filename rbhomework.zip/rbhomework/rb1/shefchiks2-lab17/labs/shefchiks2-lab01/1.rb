#!/usr/bin/ruby
#This program is written by Spencer Shefchik
puts "How many bits are in a kilobyte?"
bit=8
kilo=1024
puts kilo*bit
