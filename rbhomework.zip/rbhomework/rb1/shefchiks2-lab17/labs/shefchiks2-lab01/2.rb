#!/usr/bin/ruby
#This program is written by Spencer Shefchik
puts "How many bytes are in a megabyte?"
bit=8
kilo=1024
mega=1024
puts mega*kilo

