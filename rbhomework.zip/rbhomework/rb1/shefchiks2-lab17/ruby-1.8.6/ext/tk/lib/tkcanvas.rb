#
#   tkcanvas.rb - load tk/canvas.rb
#
require 'tk/canvas'
