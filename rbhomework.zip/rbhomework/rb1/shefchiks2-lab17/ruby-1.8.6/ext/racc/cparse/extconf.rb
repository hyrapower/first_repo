# $Id: extconf.rb 11708 2007-02-12 23:01:19Z shyouhei $

require 'mkmf'
create_makefile 'racc/cparse'
