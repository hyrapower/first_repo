#!/usr/bin/ruby
# This program was created by Spencer Shefchik

# For each directory or set of directories
ARGV.each do |a|
  dump_contents = %x[du -sk #{a}] # du in KB summarized
  dump_contents.each do |line|
    value = line[/^([0-9]+)/] #regex number
    key = line[/(\s.+$)/] # regex folder
    if (value.to_i / 1024) > 0 #sizecheck KB/1024
      puts "#{key} #{"#" * (value.to_i / 1024)}" # divide by 1024 for kb => mb
    else
      puts "#{key} #{value.to_i}KB" # if less than a mb put kb
    end
  end
end