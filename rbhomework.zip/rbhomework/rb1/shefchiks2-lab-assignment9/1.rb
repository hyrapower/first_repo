#!/usr/bin/ruby

#write a factorial program that DOES NOT use a recursive loop
def factorialL(x)
  sum = x
  x -= 1
  while x > 0 do
	sum *= x
	x -= 1
  end
  return sum
end

#write a recursive loop for factorials
def factorialR(x)
    return 1 if x == 1
    return x * factorialR(x-1)
end

    t_start = Time.now
	puts factorialL(16)
	t_stop = Time.now
	puts "The iterative execution time is " + (t_stop - t_start).to_s

	t_start = Time.now
	puts factorialR(16)
	t_stop = Time.now
	puts "The recursive execution time is " + (t_stop - t_start).to_s  