#!/usr/bin/ruby]
len = 0
def stringLength(x, len)
    if x.empty?
    	return len - 1
    else
   	    return stringLength(x.chop, len+=1)
	end
end

puts "give me a string"
x = gets
puts stringLength(x, len)