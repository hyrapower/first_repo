#!/usr/bin/ruby
#this program was made by Spencer Shefchik

puts "please enter your grade"
num = gets.chomp.to_i

case num
when 93..100
	print "A"
when 90..92
	print "A-"
when 87..89
	print "B+"
when 83..86
	print "B"
when 80.82
	print "B-"
when 77..79
	print "C+"
when 73..76
	print "C"
when 70..72
	print "C-"
when 67..69
	print "D+"
else
	print "F"
end

