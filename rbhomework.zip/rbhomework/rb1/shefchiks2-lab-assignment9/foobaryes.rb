#!/usr/bin/ruby

#this program is written by Spencer Shefchik

puts "welcome to foo, bar, yes, the game of chance"

arr = ["foo", "bar", "yes"]

i = rand(0..2).to_i

puts "choose wisely! 0 for foo, 1 for bar, 2 for yes"

a = gets.chomp.to_i
puts i

if a == i

   puts "cooooooooooreeeeeeeeeeeecccccctttttttttttt"

   puts "you were right it was #{arr[i]}"
else
   puts "incorrect"
end
