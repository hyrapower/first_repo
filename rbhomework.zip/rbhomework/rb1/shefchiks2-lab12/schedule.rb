#!/usr/bin/ruby
#this program was created by Spencer Shefchik

require 'date'

#wanted to figure out what today was
date = Date.jd(DateTime.now.jd)

#2014-08-19 start date
month = 8 #first month of class
day = 19 #first day of class
overflow = 0 #time days overflow into next month from incrimenting this way
weekday = 2 #tuesday
whenever = Date.new(2014, month, day) #date incriment

#########################################################

if File.exists?("../topics.txt")
	File.read("../topics.txt").each do |line|
		# overflow for each month
		# had to write the if out longhand for some reason

		if day > 30 && (month == 9 || month == 11)
			overflow = day % 30
			day = 0 + overflow
			month = month + 1
		elsif day > 31
			overflow = day % 31
			day = 0 + overflow
			month = month + 1
		end
		# all days are either tuesday or thursday
		# I decided that this was A WAY of doing it...
		# Tuesdays incriment by 2 for thursday
		# Thursday incriments by 5 for next tuesday
		if weekday == 2
			whenever = Date.new(2014, month, day) #generate new instance of date
			puts "#{whenever}: #{line}"
			weekday = 4
			day = day + 2
		elsif weekday == 4
			whenever = Date.new(2014, month, day) #generate new instance of date
			puts "#{whenever}: #{line}"
			weekday = 2
			day = day + 5
		end
	end
else
	puts "bad file path, or file does not exist at ../"
end
