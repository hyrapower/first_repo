#!/usr/bin/env ruby
#Ankur Patel
#12/4/2015

require 'rubygems'
require 'active_record'
require 'sqlite3'
require 'open-uri'
require 'nokogiri'

ActiveRecord::Base.establish_connection(
    :adapter => "sqlite3",
    :database  => "crawler.db"
)

class Page < ActiveRecord::Base
end

class Link < ActiveRecord::Base
end

#open url

doc = Nokogiri::HTML(open("http://informatics.nku.edu/index.html"))
page = doc.create!(:url => doc.url, :title => doc.title, :content_type => doc.type, :last_modified => Date.today, :error => "")

links = doc.css('a')

links.each do |a|
    page2 = nil
    p = Page.find_by_url(a["href"])
    if p.present?
        page2 = p
    else
        page2 = Page.create!(:url => a["href"], :title => a.text, :content_type => "", :last_modified => Date.today, :error => "")
    end
    link = Link.find_by_to_page_id(page2.id)
    if link.present?
        link.count = "#{link.count.to_i + 1}"
     else
        l = Link.create!(:from_page_id => page.id, :to_page_id => page2.id, :count => "1")
    end
end

